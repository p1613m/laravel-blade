<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'Blog'); ?></title>
</head>
<body>
<nav>
    <a href="<?php echo e(route('home')); ?>"><b>Blog</b></a> |
    <?php if(auth()->guard()->check()): ?>
        <a href="#">Create Post</a> |
        <a href="#">My Posts</a> |
        <a href="<?php echo e(route('logout')); ?>">Logout</a>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('register')); ?>">Register</a> |
        <a href="<?php echo e(route('auth')); ?>">Login</a>
    <?php endif; ?>
</nav>

<?php echo $__env->yieldContent('content'); ?>

<footer>
    &copy; My Blog 2022
</footer>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\laravel-blade\resources\views/layout.blade.php ENDPATH**/ ?>