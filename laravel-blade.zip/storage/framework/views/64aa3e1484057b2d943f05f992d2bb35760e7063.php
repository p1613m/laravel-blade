<?php $__env->startSection('content'); ?>
<h1>Blog</h1>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\laravel-blade\resources\views/index.blade.php ENDPATH**/ ?>