@extends('layout')

@section('content')
<h1>Blog</h1>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
<article>
    <h2>Post title</h2>
    <p><u><a href="#">User</a>. 04.08.2022</u></p>
    <p>Description</p>
    <a href="#">Read more..</a>
    <hr>
</article>
@endsection
