@extends('layout')

@section('content')
    <article>
        <h1>Post title</h1>
        <p><u><a href="#">User</a>. 04.08.2022</u></p>
        <p>Description</p>
        <p>Content</p>
    </article>
@endsection
